﻿using BankAPI.Services;
using log4net.Config;
using log4net.Core;
using log4net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;

namespace BankAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ADMINController : ControllerBase
    {
        IServAdminControls controls;
        
        public ADMINController(IServAdminControls controls)
        {
            this.controls = controls;
         
        }

        private void LogError(string message)
        {
            var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
            XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));
            ILog _logger = LogManager.GetLogger(typeof(LoggerManager));
            _logger.Info(message);
        }

        //ServAdminControls controls=new ServAdminControls();

        [HttpPut("Acc User")]
     public IActionResult Approve(string username) 
        {
        controls.Approve(username);
        return Ok();    
        }

        [HttpPut("Free User")]
    public IActionResult Block(string username)
        {
            controls.Block(username);
            return Ok();
        }
     
        [HttpPut("UnFree User")]
        public IActionResult UnBlock(string username)
        {
            controls.UnBlock(username);
            return Ok();
        }
    }
}
