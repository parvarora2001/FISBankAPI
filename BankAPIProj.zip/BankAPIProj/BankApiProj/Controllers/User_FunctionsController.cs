﻿using BankAPI.Services;
using log4net.Config;
using log4net.Core;
using log4net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;
using BankAPI.Models;

namespace BankAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class User_FunctionsController : ControllerBase
    {
        IServUserControls controls;

        public User_FunctionsController(IServUserControls controls)
        {
            this.controls = controls;

        }
        private void LogError(string message)
        {
            var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
            XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));
            ILog _logger = LogManager.GetLogger(typeof(LoggerManager));
            _logger.Info(message);
            
        }
        [HttpPost("Create")]
        public async Task<IActionResult>  CreateAccount( Account account)
        {
           await controls.CreateAccount(account);
            return Ok();

        }

        [HttpPut("Depo")]
        public async Task <IActionResult> Deposit(float amount, int Accn)
        {
            LogError($"Deposit #{Accn}:{amount}");
                await controls.Deposit(amount, Accn);
                return Ok();

        }

        [HttpPut("WithD")]
        public async Task<IActionResult> Withdraw(float amount, int Accn)
        {
                await controls.Withdraw(amount, Accn);
                return Ok();
        }


        [HttpPut("Transf")]
        public async Task <IActionResult>  Transfer(float amount, int SenderAccno, int RecieverAccno)
        {
            LogError($"Transfer #{SenderAccno}:{amount} to #{RecieverAccno}:{amount}");
            await controls.Transfer(amount, SenderAccno, RecieverAccno);
            return Ok();
        }

        [HttpGet("GetDetails")]
        public IActionResult TransactionDetails(int Accno)
        {

          return Ok(  controls.TransactionDetails(Accno));
            
        }

    }
}
