﻿
using BankAPI.Repositary.Admin;

namespace BankAPI.Services
{
    public class ServAdminControls:IServAdminControls
    {
        IRepoAdminControls RAdmin;
        

        public ServAdminControls(IRepoAdminControls RAdmin)
        {
            this.RAdmin = RAdmin;

        }

        public async Task Approve (string username)
        {
            RAdmin.Approve(username);
        }

        public async Task Block(string username)
        {
            RAdmin.Block(username);
        }

        public async Task UnBlock(string username)
        {
            RAdmin.UnBlock(username);
        }

    }
}
