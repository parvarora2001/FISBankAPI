﻿using System;
using System.Collections.Generic;

namespace BankAPI.Models;

public partial class Account
{
    public string UserName { get; set; } = null!;

    public string? Password { get; set; }

    public string? CustomerName { get; set; }

    public string? CustomerAddress { get; set; }

    public double? CurrentBalance { get; set; }

    public string? Email { get; set; }

    public string? City { get; set; }

    public int? PhoneNumber { get; set; }

    public int? CardNumber { get; set; }

    public int? PinNumber { get; set; }

    public string? AccountType { get; set; }

    public bool? BlockStatus { get; set; }

    public int? AccountNumber { get; set; }

    public bool? ApproveStatus { get; set; }
}
