﻿using System;
using System.Collections.Generic;

namespace BankAPI.Models;

public partial class Transaction
{
    public int TransactionId { get; set; }

    public DateTime? TransactionDate { get; set; }

    public int? AccountNumber { get; set; }

    public string? UserName { get; set; }

    public float? Amount { get; set; }

    public string? TransactionType { get; set; }
}
