﻿using System;
using System.Collections.Generic;

namespace BankAPI.Models;

public partial class UserDatatable
{
    public string UserName { get; set; } = null!;

    public string? Password { get; set; }

    public int? AccountNum { get; set; }

    public bool? BlockStatus { get; set; }
}
